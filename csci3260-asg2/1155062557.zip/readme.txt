	CSCI3260 Assignment 2 Keyboard / Mouse Events  

Name: Ling Leong
Student ID: 1155062557

Additional notice:
There is a purple spot light at camera postion and point to camera direction. 
Move camera close to object to see its effect


Manipulation:

		Key "Esc": exit program
		
		Key "m": toggle wireframe mode
		
		Key "c": toggle free camera mode:
		In free camera mode:
		{
		Mouse Click and hold + Mouse movement: change camera direction
		}
		
		Key "i": move camera forward
		Key "k": move camera backward
		Key "j": move camera left
		Key "l": move camera right
		
		Mouse scroll up: decrease fov
		Mouse scroll down: increase fov
		
		Mouse movement:
		When mouse moves up, camera moves down
		When mouse moves left, camera moves right	
		When mouse moves down, camera moves up
		When mouse moves right, camera moves left

		Key "Arrow Up": move car forward
		Key "Arrow Down": move car backward
		Key "Arrow Left": turn car left
		Key "Arrow Right": turn car right
		Key "9": move car down
		Key "0": turn car up
		
		Key "z": increase brightness of specular light
		Key "x": reduce brightness of specular light
		Key "q": increase brightness of diffuse light
		Key "w": reduce brightness of diffuse light
		
		Key "t": rotate every object anticlockwisely along (0, 1, 0)
		Key "g": rotate  every object clockwisely along (0, 1, 0)

		Key "s" : toggle the auto rotation of car

		Key "=" : scale up every object 
		Key "-" : scale down every object
		Key "," : reduce camera sensitivity
		Key "." : increase camera sensitivity
		
		

